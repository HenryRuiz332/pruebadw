<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Estudiantes extends Model
{
	protected $table = "estudiantes";

	protected $primaryKey = "id";

    protected $filleable = ["nombre", "apellido", "sexo", "fecha_de_nacimiento","email", "estado", "ciudad", "carrera", "status"];

    protected $guarded = array();
}
