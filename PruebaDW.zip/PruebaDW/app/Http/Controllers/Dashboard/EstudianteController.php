<?php

namespace App\Http\Controllers\Dashboard;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Estudiantes;
use App\Carrera;

class EstudianteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $estudiantes = Estudiantes::orderBy("id", "DESC")->where("status", "Activo")->paginate(10); 

         return view("estudiantes.index", compact("estudiantes"));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view("estudiantes.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($request->isMethod("post")) {
            $data = $request->all();
            $estudiante = new Estudiantes;
           
            $estudiante->nombre= $data["nombre"];
            $estudiante->apellido= $data["apellido"];
            $estudiante->sexo= $data["sexo"];
            $estudiante->carrera= $data["carrera"];
            $estudiante->fecha_de_nacimiento= $data["fecha_de_nacimiento"];
            $estudiante->email= $data["email"];
            if (empty($data["estado"])) {
            $data["estado"]="";
            }
            if (empty($data["ciudad"])) {
            $data["ciudad"]="";
            }
            $estudiante->carrera= $data["carrera"];

        }

        if (empty($data["status"])) {
            $status = "Activo";
        }else{
            $status = "Inactivo";
        }

        $estudiante->status = $status;

        $estudiante->save();
         return redirect()->route("estudiantes.index")->with("info", "¡Estudiante registrado!");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $estudiante = Estudiantes::find($id);
        $carrera = Carrera::find($id);
        return view("estudiantes.show", compact("estudiante", "carrera"));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $estudiante = Estudiantes::find($id);

        return view("estudiantes.edit", compact("estudiante"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $estudiante=Estudiantes::findOrFail($id);
        $estudiante->nombre=$request->get('nombre');
        $estudiante->apellido=$request->get("apellido");
        $estudiante->sexo=$request->get("sexo");
        $estudiante->fecha_de_nacimiento=$request->get("fecha_de_nacimiento");
        $estudiante->email=$request->get("email");
        if (empty($data["estado"])) {
            $data["estado"]="";
            }
            if (empty($data["ciudad"])) {
            $data["ciudad"]="";
            }
        if (empty($data["status"])) {
            $status = "Inactivo";
        }else{
            $status = "Activo";
        }
         if (empty($data["carrera"])) {
            $data["carrera"]="";
            }
       

        $estudiante->update();

         return redirect()->route("estudiantes.edit",$estudiante->id)->with("info","Información actualizada");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         $estudiante = Estudiantes::find($id)->delete();

        return back()->with("info", "Estudiante eliminado" );
    }
}
