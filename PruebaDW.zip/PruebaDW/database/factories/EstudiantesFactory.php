<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Estudiantes;
use Faker\Generator as Faker;

$factory->define(Estudiantes::class, function (Faker $faker) {
    $title=$faker->sentence(2);
    $sexo=$faker->sentence(1);
    return [
        //

        "nombre" => $title,
        "apellido" => $title,
        "sexo" => $sexo,
        "fecha_de_nacimiento" => $faker->date(),
        "estado" => $title,
        "ciudad" => $title,
        'email' => $faker->unique()->safeEmail,
        "carrera" => $title,
        "status" => $faker->randomElement(["Inactivo", "Activo"]), 
    ];
});
