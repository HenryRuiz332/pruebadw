        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
                <h3>Menu</h3>
                <ul class="nav side-menu">
                   
                    <li><a class="waves-effect waves-light" ><i class="fa fa-users"></i> Estudiantes <span
                                    class="fa fa-chevron-right"></span></a>
                        <ul class="nav child_menu">
                            <li><a class="waves-effect waves-light" href="<?php echo e(route("estudiantes.create")); ?>">Registrar</a></li>
                            <li><a class="waves-effect waves-light" href="<?php echo e(route("estudiantes.index")); ?>">Ver todos</a></li>
                        </ul>
                    </li>
                </ul>
            </div>      
        </div><?php /**PATH A:\laragon\www\PruebaDW\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>