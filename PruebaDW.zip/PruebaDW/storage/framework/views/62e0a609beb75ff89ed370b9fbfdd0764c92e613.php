<div class="modal fade" id="modal-delete-<?php echo e($estudiante->id); ?>">
    
    <form method="post" action="<?php echo e(route("estudiantes.destroy", $estudiante->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field("DELETE"); ?>
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header danger-modal">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Eliminar Estudiante</h4>
            </div>
            <div class="modal-body">
                <p>¿Estás seguro eliminarlo </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default float-button-light" data-dismiss="modal">No</button>
                <button type="submit" class="btn btn-danger float-button-light">Si</button>
            </div>
        </div>
    </div>
    </form>
</div>


 <?php /**PATH A:\laragon\www\PruebaDW\resources\views/estudiantes/modal_delete.blade.php ENDPATH**/ ?>