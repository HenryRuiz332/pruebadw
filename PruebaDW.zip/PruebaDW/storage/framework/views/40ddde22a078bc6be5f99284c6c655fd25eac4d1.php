<?php $__env->startSection("content"); ?>
	
	 <h2 class="page-name-title">Registrar nuevo estudiante</h2>
	   <div class="container">
		   <div class="row">
			   	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		            <div class="section-body">
		            	<form method="post" action="<?php echo e(route("estudiantes.store")); ?>">
	                        <?php echo e(csrf_field()); ?>

				            <div class="form-item">
				                <p class="formLabel">Nombre</p>
				                <input type="text" name="nombre" class="form-style" autocomplete="off" />
				            </div>

				            <div class="form-item">
				                <p class="formLabel">Apellido</p>
				                <input type="text" name="apellido" class="form-style" autocomplete="off" />
				            </div>

				            <div class="form-item">
				                <label>Sexo</label>
				                <select name="sexo" class="form-style">
				                	<option value="Maculino" >Maculino</option>
				                	<option value="Femenino">Femenino</option>
				                </select>
				            </div>

				            <div class="form-item">
				                <p class="formLabel">Fecha Nacimiento</p>
				                <input type="date" name="fecha_de_nacimiento" class="form-style" autocomplete="off" />
				            </div>

				            <div class="form-item">
				                <p class="formLabel">Email</p>
				                <input type="text" name="email" class="form-style" autocomplete="off" />
				            </div>

				            
				            <div class="form-item">
				                <p class="formLabel">Carrera</p>
				                <input type="text" name="carrera" class="form-style" autocomplete="off" />
				            </div>

				            <div class="form-item">
				                <button type="submit" class="btn btn-primary">Enviar</button>
				                 <a href="<?php echo e(route("estudiantes.index")); ?>"> <button type="button" class="btn btn-warning">Cancelar</button></a>
				            </div>
				         </form>
		        	</div>
		       </div>
		   </div>	
	   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
	<script src="<?php echo e(asset("assets/global/js/form_input.min.js")); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.theme", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\PruebaDW\resources\views/estudiantes/create.blade.php ENDPATH**/ ?>