<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="description" content="bootstrap default admin template">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Registrarse</title>

    <!-- START GLOBAL CSS -->
    <link href="<?php echo e(asset("assets/global/plugins/bootstrap/dist/css/bootstrap.min.css")); ?>" type="text/css" rel="stylesheet"/>
    <link href="<?php echo e(asset("assets/global/plugins/Waves/dist/waves.min.css")); ?>" type="text/css" rel="stylesheet"/>
    <!-- END GLOBAL CSS -->

    <!-- START PAGE PLUG-IN CSS -->
    <link rel="stylesheet" href="<?php echo e(asset("assets/icons_fonts/font-awesome/css/font-awesome.min.css")); ?>"/>
    <!-- END PAGE PLUG-IN CSS -->

    <!-- START TEMPLATE GLOBAL CSS -->
    <link href="<?php echo e(asset("assets/pages/register/css/user_register_v2.css")); ?>" type="text/css" rel="stylesheet"/>
    <!-- END TEMPLATE GLOBAL CSS -->

    <!-- Start favicon ico -->
    <link rel="icon" href="<?php echo e(asset("assets/favicon/prince.ico")); ?>" type="image/x-icon"/>
    <link rel="icon" type="image/png" sizes="192x192" href="<?php echo e(asset("assets/favicon/prince-192x192.png")); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset("assets/favicon/prince-180x180.png")); ?>">
    <!-- End favicon ico -->

</head>
<body>

<div class="register-background">
    <div class="register-left-section">
        <h2>Registrarse Prueba de Desarrollo</h2>
    </div>
    <!--  START REGISTER -->
    <div class="register-page">
        <div class="main-register-contain">
            <div class="register-form">
                <h4>Registrarse</h4>
                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group">
                        <input id="input-name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                        <label class="control-label" for="input-name">Nombre</label><i class="bar"></i>
                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group">
                        <input id="input-email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                        <label class="control-label" for="input-email">Email</label><i class="bar"></i>
                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group">
                        <input id="input-password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">
                        <label class="control-label" for="input-password">Contraseña</label><i class="bar"></i>
                         <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group">
                        <input id="input-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                        <label class="control-label" for="input-confirm">Confirmar Contraseña</label><i class="bar"></i>
                    </div>

                    <div class="goto-register">
                       
                        <button type="submit" class="btn btn-register float-button-light">Registrar</button>
                    </div>

                    <div class="social-media-section">
                        
                        <div class="register-bottom-text">
                            <a href="<?php echo e(route("login")); ?>">Login</a>
                        </div>
                    </div>


                </form>
            </div>
        </div>
    </div>
    <!--  END REGISTER -->
</div>


<script src="<?php echo e(asset("assets/global/plugins/jquery/dist/jquery.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/global/plugins/bootstrap/dist/js/bootstrap.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/global/plugins/Waves/dist/waves.min.js")); ?>"></script>

<script>
    function openNav() {
        document.getElementById("myNav").style.width = "100%";
    }

    function closeNav() {
        document.getElementById("myNav").style.width = "0%";
    }

    !(function ($) {
        if (typeof Waves !== 'undefined') {
            Waves.attach('.float-button-light', ['waves-button', 'waves-float', 'waves-light']);
            Waves.init();
        }
    })(jQuery);
</script>


</body>
</html><?php /**PATH A:\laragon\www\PruebaDW\resources\views/auth/register.blade.php ENDPATH**/ ?>