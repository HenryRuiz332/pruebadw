<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.mensajes", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	 <h2 class="page-name-title">Carrera del estudiante </h2>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="section-body">
        	<div class="container">
				<div class="section-header">
                            <h2><?php echo e($estudiante->nombre); ?></h2>
                        </div>
                        <div class="section-body">
                           
                            <div class="default-tab">
                                <ul class="nav nav-tabs">
                                    <li role="presentation" class="active"><a href="#home" data-toggle="tab">Carrera</a></li>
                                    <li role="presentation"><a href="#profile" data-toggle="tab">Descripcion</a></li>
                                   <li role="presentation"><a href="#status" data-toggle="tab">Estatus</a></li>
                                </ul>

                                <div class="tab-content">
                                    <div id="home" class="tab-pane fade in active">
                                        <p><?php echo e($estudiante->carrera); ?> </p>
                                    </div>
                                    <div id="profile" class="tab-pane fade">
                                        <p><?php echo e($estudiante->descripcion); ?> </p>
                                    </div>
                                    <div id="status" class="tab-pane fade">
                                        <p><?php echo e($estudiante->status); ?> </p>
                                    </div>
                                    
                                </div>
                            </div>
                       
                        </div>
			</div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.theme", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\PruebaDW\resources\views/estudiantes/show.blade.php ENDPATH**/ ?>