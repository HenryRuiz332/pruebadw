<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.mensajes", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	 <h2 class="page-name-title">Editar estudiante</h2>
	   <div class="container">
		   <div class="row">
			   	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		            <div class="section-body">
		            	<form method="post" action="<?php echo e(route("estudiantes.update", $estudiante->id)); ?>">
	                        <?php echo csrf_field(); ?>
	                        <?php echo method_field("PUT"); ?>
				            <div class="form-item">
				                <p class="formLabel">Nombre</p>
				                <input type="text" name="nombre" class="form-style" autocomplete="off" value="<?php echo e($estudiante->nombre); ?>"/>
				            </div>

				            <div class="form-item">
				                <p class="formLabel">Apellido</p>
				                <input type="text" name="apellido" class="form-style" autocomplete="off" value="<?php echo e($estudiante->apellido); ?>"/>
				            </div>

				            <div class="form-item">
				                <label>Sexo</label>
				                <select name="sexo" class="form-style">
				                	<option value="<?php echo e($estudiante->sexo); ?>">Maculino</option>
				                	<option value="<?php echo e($estudiante->sexo); ?>">Femenino</option>
				                </select>
				            </div>

				            <div class="form-item">
				                <p class="formLabel">Fecha Nacimiento</p>
				                <input type="date" name="fecha_de_nacimiento" class="form-style" autocomplete="off" value="<?php echo e($estudiante->fecha_de_nacimiento); ?>"/>
				            </div>

				            <div class="form-item">
				                <p class="formLabel">Email</p>
				                <input type="text" name="email" class="form-style" autocomplete="off" value="<?php echo e($estudiante->email); ?>"/>
				            </div>

				            <div class="form-item">
				                <p class="formLabel">Carrera</p>
				                <input type="text" name="carrera" class="form-style" autocomplete="off" value="<?php echo e($estudiante->carrera); ?>"/>
				            </div>

				            <div class="form-item">
				                <button type="submit" class="btn btn-primary">Actualizar</button>
				                 <a href="<?php echo e(route("estudiantes.index")); ?>">
				                 	<button type="button" class="btn btn-warning">Cancelar</button>
				                 </a>
				            </div>
				         </form>
		        	</div>
		       </div>
		   </div>	
	   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
	<script src="<?php echo e(asset("assets/global/js/form_input.min.js")); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.theme", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\PruebaDW\resources\views/estudiantes/edit.blade.php ENDPATH**/ ?>