<?php $__env->startSection("content"); ?>
<style type="text/css" media="screen">
	.btn1{
		width: 5vw
	}
</style>
<?php echo $__env->make("layouts.mensajes", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	 <h2 class="page-name-title">Estudiantes</h2>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="section-body">
        	<div class="container">
				<a href="<?php echo e(route("estudiantes.create")); ?>">
					 <button class="btn btn-info btn-sm">
					 	<i class="fa fa-plus">Nuevo</i>
					 </button>
				</a>
			</div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Sexo</th>
                            <th>Fecha Nacimiento</th>
                            <th>Email</th>
                            
                            <th>Carrera</th>
                            <th>Estatus</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    	<?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    <tr>
		                        <th scope="row"><?php echo e($estudiante->id); ?></th>
		                        <td><?php echo e($estudiante->nombre); ?></td>
		                        <td><?php echo e($estudiante->apellido); ?></td>
		                        <td><?php echo e($estudiante->sexo); ?></td>
		                        <td><?php echo e($estudiante->fecha_de_nacimiento); ?></td>
		                        <td><?php echo e($estudiante->email); ?></td>
		                       
		                        
		                        <td><?php echo e($estudiante->carrera); ?></td>
		                        <td><?php echo e($estudiante->status); ?></td>
		                        <td>
		                        	<a href="<?php echo e(route("estudiantes.show", $estudiante->id)); ?>" class="btn1 btn btn-primary btn-xs" style="border: none!important;" >
			                            Ver
			                          </a>
			                         <a class="btn1 btn btn-success btn-xs" href="<?php echo e(route("estudiantes.edit", $estudiante->id)); ?>" style="border: none!important;" >
			                             Actualizar
			                          </a>
			                        
			                           
			                              <button type="button" data-target="#modal-delete-<?php echo e($estudiante->id); ?>" data-toggle="modal" class="btn1 btn-danger  btn-xs float-button-light">
			                               		<span class="fa fa-trash text-white"></span> 
			                              </button>
			                            
		                        </td>
		                    </tr>   <?php echo $__env->make("estudiantes.modal_delete", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                        
                    </tbody>
                </table>
                <?php echo e($estudiantes->render()); ?>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.theme", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\laragon\www\PruebaDW\resources\views/estudiantes/index.blade.php ENDPATH**/ ?>