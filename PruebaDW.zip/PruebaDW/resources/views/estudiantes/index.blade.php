@extends("layouts.theme")

@section("content")
<style type="text/css" media="screen">
	.btn1{
		width: 5vw
	}
</style>
@include("layouts.mensajes")
	{{-- Titulo de pag --}}
	 <h2 class="page-name-title">Estudiantes</h2>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="section-body">
        	<div class="container">
				<a href="{{ route("estudiantes.create") }}">
					 <button class="btn btn-info btn-sm">
					 	<i class="fa fa-plus">Nuevo</i>
					 </button>
				</a>
			</div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Sexo</th>
                            <th>Fecha Nacimiento</th>
                            <th>Email</th>
                            {{-- <th>Estado</th>
                            <th>Ciudad</th> --}}
                            <th>Carrera</th>
                            <th>Estatus</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    	@foreach($estudiantes as $estudiante)
		                    <tr>
		                        <th scope="row">{{ $estudiante->id }}</th>
		                        <td>{{ $estudiante->nombre }}</td>
		                        <td>{{ $estudiante->apellido }}</td>
		                        <td>{{ $estudiante->sexo }}</td>
		                        <td>{{ $estudiante->fecha_de_nacimiento }}</td>
		                        <td>{{ $estudiante->email }}</td>
		                       {{--  <td>{{ $estudiante->estado }}</td> --}}
		                        {{-- <td>{{ $estudiante->ciudad }}</td> --}}
		                        <td>{{ $estudiante->carrera }}</td>
		                        <td>{{ $estudiante->status }}</td>
		                        <td>
		                        	<a href="{{ route("estudiantes.show", $estudiante->id) }}" class="btn1 btn btn-primary btn-xs" style="border: none!important;" >
			                            Ver
			                          </a>
			                         <a class="btn1 btn btn-success btn-xs" href="{{ route("estudiantes.edit", $estudiante->id) }}" style="border: none!important;" >
			                             Actualizar
			                          </a>
			                        
			                           
			                              <button type="button" data-target="#modal-delete-{{ $estudiante->id }}" data-toggle="modal" class="btn1 btn-danger  btn-xs float-button-light">
			                               		<span class="fa fa-trash text-white"></span> 
			                              </button>
			                            
		                        </td>
		                    </tr>   @include("estudiantes.modal_delete")      
	                    @endforeach
	                        
                    </tbody>
                </table>
                {{ $estudiantes->render() }}
            </div>

        </div>
    </div>

@endsection