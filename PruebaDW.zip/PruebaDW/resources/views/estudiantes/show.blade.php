@extends("layouts.theme")


@section("content")
@include("layouts.mensajes")
	{{-- Titulo de pag --}}
	 <h2 class="page-name-title">Carrera del estudiante </h2>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="section-body">
        	<div class="container">
				<div class="section-header">
                            <h2>{{ $estudiante->nombre }}</h2>
                        </div>
                        <div class="section-body">
                           
                            <div class="default-tab">
                                <ul class="nav nav-tabs">
                                    <li role="presentation" class="active"><a href="#home" data-toggle="tab">Carrera</a></li>
                                    <li role="presentation"><a href="#profile" data-toggle="tab">Descripcion</a></li>
                                   <li role="presentation"><a href="#status" data-toggle="tab">Estatus</a></li>
                                </ul>

                                <div class="tab-content">
                                    <div id="home" class="tab-pane fade in active">
                                        <p>{{ $estudiante->carrera }} </p>
                                    </div>
                                    <div id="profile" class="tab-pane fade">
                                        <p>{{ $estudiante->descripcion }} </p>
                                    </div>
                                    <div id="status" class="tab-pane fade">
                                        <p>{{ $estudiante->status }} </p>
                                    </div>
                                    
                                </div>
                            </div>
                       
                        </div>
			</div>

        </div>
    </div>

@endsection