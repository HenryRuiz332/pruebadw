@extends("layouts.theme")


@section("content")
@include("layouts.mensajes")
	{{-- Titulo de pag --}}
	 <h2 class="page-name-title">Editar estudiante</h2>
	   <div class="container">
		   <div class="row">
			   	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		            <div class="section-body">
		            	<form method="post" action="{{  route("estudiantes.update", $estudiante->id) }}">
	                        @csrf
	                        @method("PUT")
				            <div class="form-item">
				                <p class="formLabel">Nombre</p>
				                <input type="text" name="nombre" class="form-style" autocomplete="off" value="{{ $estudiante->nombre }}"/>
				            </div>

				            <div class="form-item">
				                <p class="formLabel">Apellido</p>
				                <input type="text" name="apellido" class="form-style" autocomplete="off" value="{{ $estudiante->apellido }}"/>
				            </div>

				            <div class="form-item">
				                <label>Sexo</label>
				                <select name="sexo" class="form-style">
				                	<option value="{{ $estudiante->sexo }}">Maculino</option>
				                	<option value="{{ $estudiante->sexo }}">Femenino</option>
				                </select>
				            </div>

				            <div class="form-item">
				                <p class="formLabel">Fecha Nacimiento</p>
				                <input type="date" name="fecha_de_nacimiento" class="form-style" autocomplete="off" value="{{ $estudiante->fecha_de_nacimiento }}"/>
				            </div>

				            <div class="form-item">
				                <p class="formLabel">Email</p>
				                <input type="text" name="email" class="form-style" autocomplete="off" value="{{ $estudiante->email }}"/>
				            </div>

				            <div class="form-item">
				                <p class="formLabel">Carrera</p>
				                <input type="text" name="carrera" class="form-style" autocomplete="off" value="{{ $estudiante->carrera }}"/>
				            </div>

				            <div class="form-item">
				                <button type="submit" class="btn btn-primary">Actualizar</button>
				                 <a href="{{ route("estudiantes.index") }}">
				                 	<button type="button" class="btn btn-warning">Cancelar</button>
				                 </a>
				            </div>
				         </form>
		        	</div>
		       </div>
		   </div>	
	   </div>
@endsection

@section("scripts")
	<script src="{{ asset("assets/global/js/form_input.min.js") }}"></script>
@endsection